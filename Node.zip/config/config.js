module.exports = {
    port: process.env.PORT || 3000,
    secret: process.env.JWT_SECRET || 'my-secret-key'
  };