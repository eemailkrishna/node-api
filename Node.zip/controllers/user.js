const User = require('../models/user');
const validation = require('../helpers/validations');


 const getAll = async (req, res, next) => {
    
  try {
    const users = await User.findAll();
    res.json(users);
  } catch (err) {
    next(err);
  }
};



  const deleteUser = async (req, res, next) => {
    
    try {
      const users = await User.deleteUser(req.params.id);
     if(users=='0'){
      res.status(400).json({"messages":'Record not found','status':400});
     }
      res.status(200).json({"messages":'Record deleted','status':200,users});
    } catch (err) {
      next(err);
    }
  };

  const fetchByID = async (req, res, next) => {
    
    try {
      const users = await User.fetchByID(req.params.id);
     if(users=='0'){
      res.status(400).json({"messages":'Record not found','status':400});
     }
      res.status(200).json({"messages":'Record found','status':200,users});
    } catch (err) {
      next(err);
    }
  };

  const UpdateByID = async (req, res, next) => {

    var name = req.body.name;
    var email = req.body.email;
    var password = req.body.password;

    const users1 = await validation.validate(req.body);
   if(users1.status=='400'){
     res.send(users1);
   }    
    try {
      const users = await User.UpdateByID(req.params.id, req.body);
     if(users=='0'){
      res.status(400).json({"messages":'Record not found','status':400});
     }
      res.status(200).json({"messages":'Record Updated','status':200,users});
    } catch (err) {
      next(err);
    }
  };

  module.exports = { UpdateByID,getAll ,deleteUser ,fetchByID}