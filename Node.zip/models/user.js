const db = require('../config/database');

const findAll = async () => {
const [rows] = await db.query('SELECT * FROM users ORDER BY id DESC');
return rows;
};

const findByEmail = async (email) => {
const [rows] = await db.query('SELECT * FROM users WHERE email = ?', [email]);
return rows[0];
};

const create = async (name , email,password) =>{
    const [rows1]= await db.query('SELECT * FROM users WHERE email = ?', [email]);
    if(rows1.length > 0){
       return '0';
    }
    else{
        const [rows] = await db.query('INSERT INTO users (name, email, password) VALUES (?, ?, ?)', [name, email, password]);
        return { id: rows.insertId, name, email };  
    }

}

const deleteUser = async (id)=> {
    
    const [rows1]= await db.query('SELECT * FROM users WHERE id = ?', [id]);
      
        if(rows1.length > 0){
            const [rows] = await db.query('DELETE FROM users WHERE id = ?', [id]);           
        }
        else{
            return '0';
        }
  }

  const fetchByID = async (id)=> {
    
    const [rows1]= await db.query('SELECT * FROM users WHERE id = ?', [id]);     
        if(rows1.length > 0){
            return rows1;           
        }
        else{
            return '0';
        }
  }


    const UpdateByID = async(id,data)=>{
        const { name, email, password } = data;
        const [rows1]= await db.query('SELECT * FROM users WHERE id = ?', [id]);    
        if(rows1.length > 0){
            const [data1] = await db.query('UPDATE users SET name = ?, email = ?, password = ? WHERE id = ?', [name, email, password, id]);
            return {name ,email,password};         
        }
        else{
            return '0';
        }
       
    }


  

module.exports = {findAll ,findByEmail,create,deleteUser ,fetchByID ,UpdateByID}